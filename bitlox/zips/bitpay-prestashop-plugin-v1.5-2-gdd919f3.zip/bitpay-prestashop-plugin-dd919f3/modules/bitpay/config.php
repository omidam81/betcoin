<?php
  $bitpayurl = "https://bitpay.com";
  //$bitpayurl = "https://test.bitpay.com";
  $apiurl = $bitpayurl;
  $sslport = 443;
  $verifypeer = 1;
  $verifyhost = 2;
?>
